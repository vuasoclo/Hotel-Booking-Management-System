// src/utils/api.js
// Centralized API configuration - no more hardcoded localhost:9000

const API_BASE = import.meta.env.VITE_API_URL || '/api';

class ApiError extends Error {
  constructor(status, detail) {
    super(detail);
    this.status = status;
    this.detail = detail;
  }
}

function getAuthHeaders() {
  const user = JSON.parse(sessionStorage.getItem('hbms_user') || 'null');
  const headers = { 'Content-Type': 'application/json' };
  // Future: add Bearer token here
  // if (user?.token) headers['Authorization'] = `Bearer ${user.token}`;
  return headers;
}

// Escape HTML to prevent XSS
export function escapeHtml(str) {
  if (!str) return '';
  const div = document.createElement('div');
  div.textContent = str;
  return div.innerHTML;
}

export function formatMoney(amount) {
  return new Intl.NumberFormat('vi-VN').format(Math.round(Number(amount) || 0));
}

export function formatDate(dateStr, opts) {
  if (!dateStr) return '--';
  return new Date(dateStr).toLocaleString('vi-VN', opts || {
    day: '2-digit', month: '2-digit', year: 'numeric',
    hour: '2-digit', minute: '2-digit'
  });
}

export function formatDateShort(dateStr) {
  if (!dateStr) return '--';
  return new Date(dateStr).toLocaleDateString('en-GB', {
    day: '2-digit', month: 'short', year: 'numeric'
  });
}

async function request(method, path, body = null, fetchOpt = 'json') {
  const opts = { method, headers: getAuthHeaders() };
  if (body) opts.body = JSON.stringify(body);
  
  const res = await fetch(`${API_BASE}${path}`, opts);
  
  if (!res.ok) {
    let detail = `HTTP ${res.status}`;
    try {
      const err = await res.json();
      detail = err.detail || detail;
    } catch {}
    throw new ApiError(res.status, detail);
  }
  
  if (fetchOpt === 'none') return null;
  return res.json();
}

// Auth
export const authApi = {
  login: (username, password) => request('POST', '/auth/login', { username, password }),
  logout: () => request('POST', '/auth/logout'),
};

// Calendar
export const calendarApi = {
  get: (startDate, endDate) => request('GET', `/calendar?start_date=${startDate}&end_date=${endDate}`),
  defragment: (hotelId, staffId) => request('POST', `/calendar/defragment?hotel_id=${hotelId}&staff_id=${staffId}`),
  preAssign: (data) => request('POST', '/calendar/pre-assign', data),
};

// Rooms
export const roomsApi = {
  available: (checkin, checkout) => request('GET', `/rooms/available?checkin=${checkin}&checkout=${checkout}`),
  status: () => request('GET', '/rooms/status'),
  housekeeping: (roomId, staffId) => request('POST', `/rooms/${roomId}/housekeeping?staff_id=${staffId}`),
};

// Customers
export const customersApi = {
  lookup: (phone) => request('POST', '/customers/lookup', { phone_number: phone }),
};

// Bookings
export const bookingsApi = {
  create: (data) => request('POST', '/bookings/create', data),
  get: (id) => request('GET', `/bookings/${id}`),
  checkin: (id, data) => request('POST', `/bookings/${id}/checkin`, data),
  checkout: (id, data) => request('POST', `/bookings/${id}/checkout`, data),
  cancel: (id) => request('POST', `/bookings/${id}/cancel`),
  invoice: (id, data) => request('POST', `/bookings/${id}/invoice`, data),
  payment: (id, data) => request('POST', `/bookings/${id}/payment`, data),
  addService: (id, data) => request('POST', `/bookings/${id}/services`, data),
};

// Services
export const servicesApi = {
  search: (q) => request('GET', `/services/search?q=${encodeURIComponent(q)}`),
};

// Statistics
export const statisticsApi = {
  get: (period = 'all', roomTypeId = null) => {
    let url = `/statistics?period=${period}`;
    if (roomTypeId) url += `&room_type_id=${roomTypeId}`;
    return request('GET', url);
  },
};
