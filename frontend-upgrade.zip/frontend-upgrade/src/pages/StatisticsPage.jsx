// src/pages/StatisticsPage.jsx
import { useState, useEffect, useCallback } from 'react';
import { BarChart, Bar, XAxis, YAxis, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import Layout from '../components/Layout';
import LoadingSpinner from '../components/LoadingSpinner';
import { useToast } from '../components/Toast';
import { useAuth } from '../hooks/useAuth';
import { statisticsApi, formatMoney } from '../utils/api';

const HEATMAP_COLORS = {
  0: '#F1F4F6', 25: '#D5F5E3', 50: '#82E0AA', 75: '#27AE60', 100: '#1E8449',
};

function getHpColor(rate) {
  if (rate > 75) return HEATMAP_COLORS[100];
  if (rate > 50) return HEATMAP_COLORS[75];
  if (rate > 25) return HEATMAP_COLORS[50];
  if (rate > 0) return HEATMAP_COLORS[25];
  return HEATMAP_COLORS[0];
}

export default function StatisticsPage() {
  const { isAdmin } = useAuth();
  const toast = useToast();
  const [period, setPeriod] = useState('all');
  const [roomTypeId, setRoomTypeId] = useState('');
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);

  // Redirect non-admin
  useEffect(() => {
    if (!isAdmin) { window.location.href = '/calendar'; }
  }, [isAdmin]);

  const fetchData = useCallback(async () => {
    setLoading(true);
    try {
      const d = await statisticsApi.get(period, roomTypeId || null);
      setData(d);
    } catch (err) {
      toast.error('Failed to load statistics: ' + err.message);
    } finally {
      setLoading(false);
    }
  }, [period, roomTypeId]);

  useEffect(() => { fetchData(); }, [fetchData]);

  if (!isAdmin) return null;

  const kpis = data?.kpis || {};
  const monthlyRevenue = data?.monthly_revenue || [];
  const dailyOccupancy = data?.daily_occupancy || [];

  // Prepare chart data
  const chartData = [...monthlyRevenue]
    .sort((a, b) => new Date(a.report_month) - new Date(b.report_month))
    .slice(-6)
    .map(m => ({
      month: new Date(m.report_month).toLocaleString('en', { month: 'short' }),
      Rooms: m.total_room_cost || 0,
      Services: m.total_services || 0,
      Surcharges: m.total_surcharges || 0,
    }));

  // Donut data
  const totRooms = chartData.reduce((s, d) => s + d.Rooms, 0);
  const totServices = chartData.reduce((s, d) => s + d.Services, 0);
  const totSurcharges = chartData.reduce((s, d) => s + d.Surcharges, 0);
  const overallRev = totRooms + totServices + totSurcharges;
  const roomsPct = overallRev ? Math.round(totRooms / overallRev * 100) : 0;
  const servicesPct = overallRev ? Math.round(totServices / overallRev * 100) : 0;
  const surchargesPct = overallRev ? 100 - roomsPct - servicesPct : 0;

  // Heatmap
  const dates = [...new Set(dailyOccupancy.map(d => d.date))].sort().slice(-30);
  const typesMap = {};
  dailyOccupancy.forEach(d => {
    if (!typesMap[d.type_name]) typesMap[d.type_name] = {};
    typesMap[d.type_name][d.date] = d.occupancy_rate;
  });

  // Dynamic room types from heatmap data
  const roomTypes = Object.keys(typesMap);

  return (
    <Layout currentPath="/statistics">
      {/* Header + Filters */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end', marginBottom: 24 }}>
        <h1 style={{ fontSize: 24, fontWeight: 700, color: '#1A2730', margin: 0 }}>Statistics & Reports</h1>
        <div style={{ display: 'flex', gap: 8 }}>
          <select value={period} onChange={e => setPeriod(e.target.value)} style={selectStyle}>
            <option value="all">All time</option>
            <option value="this_month">This month</option>
            <option value="last_month">Last month</option>
            <option value="this_quarter">This quarter</option>
          </select>
          <select value={roomTypeId} onChange={e => setRoomTypeId(e.target.value)} style={selectStyle}>
            <option value="">All room types</option>
            {roomTypes.map((rt, i) => (
              <option key={i} value={i + 1}>{rt}</option>
            ))}
          </select>
        </div>
      </div>

      {loading ? <LoadingSpinner text="Loading statistics..." /> : (
        <>
          {/* KPI Cards */}
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 16, marginBottom: 24 }}>
            <KpiCard label="Avg Occupancy (7d)" value={`${kpis.avg_occupancy_7d || 0}%`} />
            <KpiCard label="Bookings Count" value={kpis.bookings_count || 0} sub="Total bookings" />
            <KpiCard label="ADR" value={formatMoney(kpis.adr || 0)} sub="Average Daily Rate" />
            <KpiCard label="Total Revenue" value={formatMoney(kpis.total_revenue || 0)} />
            <KpiCard label="Collected" value={formatMoney(kpis.total_collected || 0)} sub="Including VAT" />
            <KpiCard label="Outstanding" value={formatMoney(kpis.total_outstanding || 0)} danger sub="Unpaid balance" />
          </div>

          {/* Heatmap */}
          <div style={{ background: '#fff', border: '1px solid #E2E8ED', borderRadius: 8, padding: 20, marginBottom: 24 }}>
            <h3 style={{ fontSize: 14, fontWeight: 600, color: '#5C7080', textTransform: 'uppercase', marginBottom: 16 }}>Occupancy Heatmap</h3>
            <div style={{ overflowX: 'auto' }}>
              <table style={{ borderCollapse: 'collapse', width: '100%', fontSize: 11 }}>
                <thead>
                  <tr>
                    <th style={{ width: 120, textAlign: 'left', padding: 4, color: '#5C7080' }}>Room</th>
                    {dates.map(d => (
                      <th key={d} style={{ padding: 4, textAlign: 'center', color: '#9AAAB5', fontWeight: 400 }}>
                        {new Date(d).getDate().toString().padStart(2, '0')}
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {Object.entries(typesMap).map(([typeName, datesMap]) => (
                    <tr key={typeName}>
                      <td style={{ padding: 4, fontWeight: 600, color: '#2C3E4A', fontSize: 12 }}>{typeName}</td>
                      {dates.map(d => {
                        const rate = datesMap[d] || 0;
                        return (
                          <td key={d} style={{ padding: 2 }}>
                            <div title={`${rate}%`} style={{
                              width: 24, height: 24, borderRadius: 3,
                              background: getHpColor(rate), margin: '0 auto',
                            }} />
                          </td>
                        );
                      })}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginTop: 12, paddingTop: 12, borderTop: '1px solid #E2E8ED' }}>
              <span style={{ fontSize: 11, color: '#9AAAB5' }}>0%</span>
              {[0, 25, 50, 75, 100].map(v => (
                <div key={v} style={{ width: 16, height: 16, borderRadius: 3, background: HEATMAP_COLORS[v] }} />
              ))}
              <span style={{ fontSize: 11, color: '#9AAAB5' }}>100%</span>
            </div>
          </div>

          {/* Charts Row */}
          <div style={{ display: 'grid', gridTemplateColumns: '2fr 1fr', gap: 20 }}>
            {/* Revenue Chart */}
            <div style={{ background: '#fff', border: '1px solid #E2E8ED', borderRadius: 8, padding: 20 }}>
              <h3 style={{ fontSize: 14, fontWeight: 600, color: '#5C7080', textTransform: 'uppercase', marginBottom: 16 }}>Monthly Revenue</h3>
              {chartData.length === 0 ? (
                <p style={{ color: '#9AAAB5', fontSize: 13, textAlign: 'center', padding: 40 }}>No revenue data available.</p>
              ) : (
                <ResponsiveContainer width="100%" height={260}>
                  <BarChart data={chartData} barCategoryGap="20%">
                    <XAxis dataKey="month" tick={{ fontSize: 12, fill: '#9AAAB5' }} />
                    <YAxis tick={{ fontSize: 11, fill: '#9AAAB5' }} tickFormatter={v => `${(v / 1e6).toFixed(0)}M`} />
                    <Tooltip formatter={(v) => formatMoney(v) + ' ₫'} />
                    <Legend iconSize={10} wrapperStyle={{ fontSize: 12 }} />
                    <Bar dataKey="Rooms" stackId="a" fill="#0D87A8" radius={[0, 0, 0, 0]} />
                    <Bar dataKey="Surcharges" stackId="a" fill="#F1C40F" />
                    <Bar dataKey="Services" stackId="a" fill="#27AE60" radius={[4, 4, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              )}
            </div>

            {/* Donut Chart */}
            <div style={{ background: '#fff', border: '1px solid #E2E8ED', borderRadius: 8, padding: 20, display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
              <h3 style={{ fontSize: 14, fontWeight: 600, color: '#5C7080', textTransform: 'uppercase', marginBottom: 16, width: '100%' }}>Revenue Breakdown</h3>
              <div style={{ position: 'relative', width: 160, height: 160, marginBottom: 20 }}>
                <svg viewBox="0 0 36 36" style={{ transform: 'rotate(-90deg)' }}>
                  <circle cx="18" cy="18" r="15.915" fill="transparent" stroke="#E2E8ED" strokeWidth="4" strokeDasharray="100 0" />
                  <circle cx="18" cy="18" r="15.915" fill="transparent" stroke="#0D87A8" strokeWidth="4"
                    strokeDasharray={`${roomsPct} ${100 - roomsPct}`} strokeDashoffset="0" />
                  <circle cx="18" cy="18" r="15.915" fill="transparent" stroke="#27AE60" strokeWidth="4"
                    strokeDasharray={`${servicesPct} ${100 - servicesPct}`} strokeDashoffset={`-${roomsPct}`} />
                  <circle cx="18" cy="18" r="15.915" fill="transparent" stroke="#F1C40F" strokeWidth="4"
                    strokeDasharray={`${surchargesPct} ${100 - surchargesPct}`} strokeDashoffset={`-${roomsPct + servicesPct}`} />
                </svg>
                <div style={{
                  position: 'absolute', top: '50%', left: '50%', transform: 'translate(-50%,-50%)',
                  textAlign: 'center',
                }}>
                  <div style={{ fontSize: 11, color: '#9AAAB5' }}>Total</div>
                  <div style={{ fontWeight: 700, fontSize: 16 }}>{overallRev ? `${(overallRev / 1e6).toFixed(1)}M` : '0'}</div>
                </div>
              </div>
              <div style={{ width: '100%' }}>
                <LegendRow color="#0D87A8" label="Rooms" pct={`${roomsPct}%`} />
                <LegendRow color="#27AE60" label="Services" pct={`${servicesPct}%`} />
                <LegendRow color="#F1C40F" label="Surcharges" pct={`${surchargesPct}%`} />
              </div>
            </div>
          </div>
        </>
      )}
    </Layout>
  );
}

function KpiCard({ label, value, sub, danger }) {
  return (
    <div style={{
      background: '#fff', border: '1px solid #E2E8ED', borderRadius: 8, padding: 20,
    }}>
      <div style={{ fontSize: 12, color: '#9AAAB5', fontWeight: 600, textTransform: 'uppercase', marginBottom: 8 }}>{label}</div>
      <div style={{ fontSize: 28, fontWeight: 700, color: danger ? '#C0392B' : '#1A2730', fontFamily: 'monospace' }}>{value}</div>
      {sub && <div style={{ fontSize: 12, color: danger ? '#E74C3C' : '#9AAAB5', marginTop: 2 }}>{sub}</div>}
    </div>
  );
}

function LegendRow({ color, label, pct }) {
  return (
    <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 13, marginBottom: 6 }}>
      <span style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
        <span style={{ width: 10, height: 10, borderRadius: '50%', background: color, display: 'inline-block' }} />
        {label}
      </span>
      <strong>{pct}</strong>
    </div>
  );
}

const selectStyle = {
  height: 36, border: '1px solid #E2E8ED', borderRadius: 4, padding: '0 12px',
  fontSize: 13, color: '#2C3E4A', width: 150, outline: 'none',
};
