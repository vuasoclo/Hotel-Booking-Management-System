// src/hooks/useAuth.js
import { useState, useCallback } from 'react';

export function useAuth() {
  const [user, setUser] = useState(() => {
    try {
      return JSON.parse(sessionStorage.getItem('hbms_user') || 'null');
    } catch { return null; }
  });

  const login = useCallback((userData) => {
    sessionStorage.setItem('hbms_user', JSON.stringify(userData));
    setUser(userData);
  }, []);

  const logout = useCallback(() => {
    sessionStorage.removeItem('hbms_user');
    setUser(null);
  }, []);

  const isAdmin = user?.role === 'admin' || user?.role === 'Admin';
  const staffId = user?.staffId || 1;

  return { user, login, logout, isAdmin, staffId };
}
