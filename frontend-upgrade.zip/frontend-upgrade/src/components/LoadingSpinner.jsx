// src/components/LoadingSpinner.jsx
export default function LoadingSpinner({ text = 'Loading...' }) {
  return (
    <div style={{
      display: 'flex', flexDirection: 'column', alignItems: 'center',
      justifyContent: 'center', padding: '60px 0', gap: 12, color: '#9AAAB5'
    }}>
      <div style={{
        width: 32, height: 32, border: '3px solid #E2E8ED',
        borderTop: '3px solid #0D87A8', borderRadius: '50%',
        animation: 'spin 0.8s linear infinite'
      }} />
      <span style={{ fontSize: 13, fontWeight: 500 }}>{text}</span>
      <style>{`@keyframes spin { to { transform: rotate(360deg); } }`}</style>
    </div>
  );
}
