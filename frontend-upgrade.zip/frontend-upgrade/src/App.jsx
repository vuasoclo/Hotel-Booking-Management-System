// src/App.jsx
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { ToastProvider } from './components/Toast';
import LoginPage from './pages/LoginPage';
import CalendarPage from './pages/CalendarPage';
import RoomsPage from './pages/RoomsPage';
import NewReservationPage from './pages/NewReservationPage';
import BookingDetailPage from './pages/BookingDetailPage';
import StatisticsPage from './pages/StatisticsPage';

function PrivateRoute({ children }) {
  const user = JSON.parse(sessionStorage.getItem('hbms_user') || 'null');
  if (!user) return <Navigate to="/" replace />;
  return children;
}

export default function App() {
  return (
    <ToastProvider>
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<LoginPage />} />
          <Route path="/calendar" element={<PrivateRoute><CalendarPage /></PrivateRoute>} />
          <Route path="/rooms" element={<PrivateRoute><RoomsPage /></PrivateRoute>} />
          <Route path="/new-reservation" element={<PrivateRoute><NewReservationPage /></PrivateRoute>} />
          <Route path="/booking/:id" element={<PrivateRoute><BookingDetailPage /></PrivateRoute>} />
          <Route path="/statistics" element={<PrivateRoute><StatisticsPage /></PrivateRoute>} />
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </BrowserRouter>
    </ToastProvider>
  );
}
