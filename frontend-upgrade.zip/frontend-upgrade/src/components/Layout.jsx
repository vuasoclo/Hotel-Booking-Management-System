// src/components/Layout.jsx
import { useAuth } from '../hooks/useAuth';

const NAV_ITEMS = [
  { path: '/calendar', icon: 'calendar', label: 'Calendar' },
  { path: '/new-reservation', icon: 'plus-square', label: 'New Reservation' },
  { path: '/rooms', icon: 'layout', label: 'Rooms' },
  { path: '/statistics', icon: 'bar-chart-2', label: 'Statistics', adminOnly: true },
];

function FeatherIcon({ name, size = 16, className = '' }) {
  // Simple SVG icons matching feather-icons
  const icons = {
    'calendar': <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><rect x="3" y="4" width="18" height="18" rx="2" ry="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/></svg>,
    'plus-square': <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><rect x="3" y="3" width="18" height="18" rx="2" ry="2"/><line x1="12" y1="8" x2="12" y2="16"/><line x1="8" y1="12" x2="16" y2="12"/></svg>,
    'layout': <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><rect x="3" y="3" width="18" height="18" rx="2" ry="2"/><line x1="3" y1="9" x2="21" y2="9"/><line x1="9" y1="21" x2="9" y2="9"/></svg>,
    'bar-chart-2': <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><line x1="18" y1="20" x2="18" y2="10"/><line x1="12" y1="20" x2="12" y2="4"/><line x1="6" y1="20" x2="6" y2="14"/></svg>,
    'log-out': <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" y1="12" x2="9" y2="12"/></svg>,
    'bell': <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.73 21a2 2 0 0 1-3.46 0"/></svg>,
    'box': <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"/></svg>,
  };
  return <span className={className} style={{ display: 'inline-flex' }}>{icons[name] || null}</span>;
}

export default function Layout({ children, currentPath }) {
  const { user, logout, isAdmin } = useAuth();

  if (!user) {
    window.location.href = '/';
    return null;
  }

  const filteredNav = NAV_ITEMS.filter(item => !item.adminOnly || isAdmin);

  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100vh' }}>
      {/* Topbar */}
      <header style={{
        height: 56, background: '#fff', borderBottom: '1px solid #E2E8ED',
        display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '0 20px',
        flexShrink: 0
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
          <FeatherIcon name="box" size={20} className="" />
          <span style={{ fontWeight: 600, color: '#1A2730', fontSize: 15 }}>Little Hotelier</span>
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 16 }}>
          <span style={{ fontSize: 13, color: '#5C7080', fontWeight: 600 }}>{user.name}</span>
          {isAdmin && (
            <span style={{
              fontSize: 11, background: '#FFF3CD', color: '#856404', padding: '2px 8px',
              borderRadius: 4, fontWeight: 600
            }}>Admin</span>
          )}
          <FeatherIcon name="bell" size={18} className="" />
          <button onClick={logout} style={{
            display: 'flex', alignItems: 'center', gap: 6, padding: '4px 12px',
            border: '1px solid #E2E8ED', borderRadius: 4, background: 'transparent',
            fontSize: 13, cursor: 'pointer', color: '#5C7080'
          }}>
            <FeatherIcon name="log-out" size={14} /> Logout
          </button>
        </div>
      </header>

      <div style={{ display: 'flex', flex: 1, overflow: 'hidden' }}>
        {/* Sidebar */}
        <aside style={{
          width: 240, background: '#F1F4F6', borderRight: '1px solid #E2E8ED',
          padding: '16px 0', flexShrink: 0, overflowY: 'auto'
        }}>
          <nav>
            {filteredNav.map(item => {
              const isActive = currentPath === item.path;
              return (
                <a key={item.path} href={item.path} style={{
                  height: 40, display: 'flex', alignItems: 'center', padding: '0 16px',
                  marginBottom: 4, textDecoration: 'none', fontSize: 14,
                  color: isActive ? '#0A6B87' : '#2C3E4A',
                  fontWeight: isActive ? 600 : 400,
                  background: isActive ? '#EFF8FB' : 'transparent',
                  borderRight: isActive ? '3px solid #0D87A8' : '3px solid transparent',
                  gap: 10, transition: 'all 0.15s',
                }}>
                  <FeatherIcon name={item.icon} size={18} />
                  {item.label}
                </a>
              );
            })}
          </nav>
        </aside>

        {/* Main Content */}
        <main style={{
          flex: 1, overflow: 'auto', padding: 24,
          background: '#F8FAFB'
        }}>
          <div style={{ maxWidth: 1280, margin: '0 auto', width: '100%' }}>
            {children}
          </div>
        </main>
      </div>
    </div>
  );
}

export { FeatherIcon };
