// src/pages/BookingDetailPage.jsx
import { useState, useEffect, useCallback } from 'react';
import Layout from '../components/Layout';
import LoadingSpinner from '../components/LoadingSpinner';
import { useToast } from '../components/Toast';
import { useAuth } from '../hooks/useAuth';
import { bookingsApi, servicesApi, formatMoney, formatDate, escapeHtml } from '../utils/api';

const STATUS_STYLES = {
  Active:       { bg: '#EBF5FB', color: '#2E86C1', border: '#2E86C1' },
  'Checked-in': { bg: '#EAFAF1', color: '#27AE60', border: '#27AE60' },
  Completed:    { bg: '#F2F3F4', color: '#6B7A8D', border: '#BDC3C7' },
  Cancelled:    { bg: '#FDEDEC', color: '#C0392B', border: '#E74C3C' },
};

export default function BookingDetailPage() {
  const { staffId } = useAuth();
  const toast = useToast();
  const bookingId = window.location.pathname.split('/').pop();

  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [actionLoading, setActionLoading] = useState(false);

  // Modals
  const [showPayment, setShowPayment] = useState(false);
  const [showInvoice, setShowInvoice] = useState(false);
  const [showService, setShowService] = useState(false);

  // Payment form
  const [payAmount, setPayAmount] = useState('');
  const [payMethod, setPayMethod] = useState('Cash');

  // Service search
  const [svcQuery, setSvcQuery] = useState('');
  const [svcResults, setSvcResults] = useState([]);

  // Accordion
  const [openSection, setOpenSection] = useState(null);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const d = await bookingsApi.get(bookingId);
      setData(d);
    } catch (err) {
      toast.error('Failed to load booking: ' + err.message);
    } finally {
      setLoading(false);
    }
  }, [bookingId]);

  useEffect(() => { load(); }, [load]);

  // Service search debounce
  useEffect(() => {
    if (!svcQuery.trim()) { setSvcResults([]); return; }
    const t = setTimeout(async () => {
      try {
        const res = await servicesApi.search(svcQuery);
        setSvcResults(res);
      } catch {}
    }, 300);
    return () => clearTimeout(t);
  }, [svcQuery]);

  if (loading) return <Layout currentPath=""><LoadingSpinner text="Loading booking..." /></Layout>;
  if (!data) return <Layout currentPath=""><p style={{ padding: 40, color: '#9AAAB5' }}>Booking not found.</p></Layout>;

  const status = data.status;
  const stStyle = STATUS_STYLES[status] || STATUS_STYLES.Active;
  const inits = data.customer_name ? data.customer_name.split(' ').map(n => n[0]).join('').substring(0, 2).toUpperCase() : 'G';

  // Cost calc
  const surchargesTotal = (data.surcharges || []).reduce((s, x) => s + Number(x.amount), 0);
  const servicesTotal = (data.services || []).reduce((s, x) => s + Number(x.quantity) * Number(x.unit_price), 0);
  const totalAmount = Number(data.total_amount || 0);
  const amountPaid = Number(data.amount_paid || 0);
  const roomsTotal = Math.max(totalAmount - surchargesTotal - servicesTotal, 0);
  const balance = totalAmount - amountPaid;

  // Actions
  const handleCheckIn = async () => {
    if (!data.room_assignments?.length) return;
    setActionLoading(true);
    try {
      for (const ra of data.room_assignments) {
        await bookingsApi.checkin(bookingId, { room_id: ra.room_id, staff_id: staffId });
      }
      toast.success('Check-in successful!');
      load();
    } catch (err) {
      toast.error('Check-in failed: ' + err.message);
    } finally { setActionLoading(false); }
  };

  const handleCheckOut = async () => {
    setActionLoading(true);
    try {
      await bookingsApi.checkout(bookingId, { staff_id: staffId });
      toast.success('Check-out successful!');
      load();
    } catch (err) {
      toast.error('Check-out failed: ' + err.message);
    } finally { setActionLoading(false); }
  };

  const handleCancel = async () => {
    if (!confirm('Are you sure you want to cancel this booking?')) return;
    setActionLoading(true);
    try {
      await bookingsApi.cancel(bookingId);
      toast.success('Booking cancelled.');
      load();
    } catch (err) {
      toast.error('Cancel failed: ' + err.message);
    } finally { setActionLoading(false); }
  };

  const handlePayment = async () => {
    const amt = Number(payAmount);
    if (!amt || amt <= 0) { toast.warning('Enter a valid amount'); return; }
    setActionLoading(true);
    try {
      await bookingsApi.payment(bookingId, { amount: amt, payment_method: payMethod, staff_id: staffId });
      toast.success('Payment recorded!');
      setShowPayment(false);
      load();
    } catch (err) {
      toast.error('Payment failed: ' + err.message);
    } finally { setActionLoading(false); }
  };

  const handleInvoice = async () => {
    setActionLoading(true);
    try {
      await bookingsApi.invoice(bookingId, { staff_id: staffId });
      toast.success('Invoice issued!');
      setShowInvoice(false);
      load();
    } catch (err) {
      toast.error('Invoice failed: ' + err.message);
    } finally { setActionLoading(false); }
  };

  const handleAddService = async (svc) => {
    try {
      await bookingsApi.addService(bookingId, { service_id: svc.id, quantity: 1, staff_id: staffId });
      toast.success('Service added!');
      setShowService(false);
      setSvcQuery('');
      load();
    } catch (err) {
      toast.error('Failed: ' + err.message);
    }
  };

  return (
    <Layout currentPath="">
      {/* Back + Title */}
      <a href="/calendar" style={{ fontSize: 13, color: '#9AAAB5', textDecoration: 'none', display: 'flex', alignItems: 'center', gap: 4, marginBottom: 8 }}>
        ← Back to Calendar
      </a>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 24 }}>
        <h1 style={{ fontSize: 24, fontWeight: 700, color: '#1A2730', margin: 0 }}>
          Booking #BK-{String(data.booking_id).padStart(5, '0')}
        </h1>
        <span style={{
          padding: '6px 16px', borderRadius: 20, fontWeight: 600, fontSize: 13,
          background: stStyle.bg, color: stStyle.color, border: `1px solid ${stStyle.border}`,
        }}>{status}</span>
      </div>

      {/* Grid */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 20, marginBottom: 24 }}>
        {/* Guest Info */}
        <Card title="Guest Information">
          <div style={{ display: 'flex', alignItems: 'center', gap: 14, marginBottom: 16 }}>
            <div style={{
              width: 48, height: 48, borderRadius: '50%', background: '#0D87A8', color: '#fff',
              display: 'flex', alignItems: 'center', justifyContent: 'center', fontWeight: 700, fontSize: 18,
            }}>{inits}</div>
            <div>
              <div style={{ fontWeight: 600, fontSize: 18 }}>{escapeHtml(data.customer_name || '--')}</div>
              <div style={{ fontSize: 12, color: '#9AAAB5' }}>DOB: {data.date_of_birth ? new Date(data.date_of_birth).toLocaleDateString('en-GB') : '--'}</div>
            </div>
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
            <InfoField label="📞 Phone" value={data.customer_phone || '--'} />
            <InfoField label="🪪 ID Card" value={data.id_number || '--'} />
          </div>
        </Card>

        {/* Stay Details */}
        <Card title="Stay Details">
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12, marginBottom: 12 }}>
            <div>
              <div style={labelSm}>Check-in</div>
              <div style={{ fontWeight: 600 }}>{formatDate(data.check_in)}</div>
            </div>
            <div>
              <div style={labelSm}>Check-out</div>
              <div style={{ fontWeight: 600 }}>{formatDate(data.check_out)}</div>
              <div style={{ fontSize: 12, color: '#0D87A8' }}>{data.nights} nights</div>
            </div>
          </div>
          <div style={labelSm}>Rooms</div>
          <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap' }}>
            {(data.room_assignments || []).map((ra, i) => (
              <span key={i} style={{
                padding: '3px 10px', borderRadius: 4, fontSize: 12, fontWeight: 600,
                background: '#F1F4F6', border: '1px solid #E2E8ED',
              }}>R{ra.room_number}</span>
            ))}
          </div>
        </Card>

        {/* Cost Breakdown */}
        <Card title="Cost Breakdown">
          <Accordion label={`Rooms (${formatMoney(roomsTotal)})`} open={openSection === 'rooms'} toggle={() => setOpenSection(openSection === 'rooms' ? null : 'rooms')}>
            <Row left="Base Rooms Cost" right={formatMoney(roomsTotal)} />
          </Accordion>
          <Accordion label={`Surcharges (${formatMoney(surchargesTotal)})`} open={openSection === 'surcharges'} toggle={() => setOpenSection(openSection === 'surcharges' ? null : 'surcharges')}>
            {(data.surcharges || []).length === 0 ? <span style={{ color: '#9AAAB5', fontSize: 12 }}>No surcharges</span> :
              data.surcharges.map((s, i) => <Row key={i} left="Fee" right={formatMoney(s.amount)} />)}
          </Accordion>
          <Accordion label={`Services (${formatMoney(servicesTotal)})`} open={openSection === 'services'} toggle={() => setOpenSection(openSection === 'services' ? null : 'services')}>
            {(data.services || []).length === 0 ? <span style={{ color: '#9AAAB5', fontSize: 12 }}>No services</span> :
              data.services.map((s, i) => <Row key={i} left={`${escapeHtml(s.service_name)} (${s.quantity})`} right={formatMoney(s.quantity * s.unit_price)} />)}
          </Accordion>

          <div style={{ marginTop: 16, paddingTop: 12, borderTop: '1px solid #E2E8ED' }}>
            <Row left="Total Amount" right={`${formatMoney(totalAmount)} ₫`} bold />
            <Row left="Amount Paid" right={`${formatMoney(amountPaid)} ₫`} color="#27AE60" />
            <div style={{ marginTop: 8, paddingTop: 8, borderTop: '1px solid #E2E8ED', display: 'flex', justifyContent: 'space-between' }}>
              <strong>Balance Due</strong>
              <strong style={{ color: '#C0392B', fontSize: 20, fontFamily: 'monospace' }}>{formatMoney(balance)} ₫</strong>
            </div>
          </div>
        </Card>

        {/* Services List */}
        <Card title="Services" action={status !== 'Completed' && status !== 'Cancelled' ? <button onClick={() => setShowService(true)} style={btnSmOutline}>+ Add Service</button> : null}>
          {(data.services || []).length === 0 ? <p style={{ color: '#9AAAB5', fontSize: 13 }}>No services used.</p> : (
            <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 13 }}>
              <thead>
                <tr style={{ borderBottom: '1px solid #E2E8ED' }}>
                  {['Service', 'Qty', 'Subtotal'].map(h => <th key={h} style={{ padding: '6px 8px', fontSize: 11, fontWeight: 600, color: '#5C7080', textTransform: 'uppercase', textAlign: 'left' }}>{h}</th>)}
                </tr>
              </thead>
              <tbody>
                {data.services.map((s, i) => (
                  <tr key={i} style={{ borderBottom: '1px solid #f0f0f0' }}>
                    <td style={{ padding: '8px 8px' }}>
                      {escapeHtml(s.service_name)}
                      <br /><span style={{ fontSize: 10, color: '#9AAAB5' }}>{formatDate(s.used_at)}</span>
                    </td>
                    <td style={{ padding: '8px 8px' }}>{s.quantity}</td>
                    <td style={{ padding: '8px 8px', fontFamily: 'monospace' }}>{formatMoney(s.quantity * s.unit_price)} ₫</td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </Card>
      </div>

      {/* Sticky Action Bar */}
      {status !== 'Cancelled' && (
        <div style={{
          position: 'sticky', bottom: 0, background: '#fff', borderTop: '1px solid #E2E8ED',
          padding: '16px 0', display: 'flex', justifyContent: 'space-between', alignItems: 'center',
          zIndex: 50, marginTop: 8,
        }}>
          {status === 'Active' && (
            <button onClick={handleCancel} disabled={actionLoading} style={{
              padding: '8px 16px', border: '1px solid #E74C3C', borderRadius: 4, background: 'transparent',
              color: '#E74C3C', fontWeight: 600, fontSize: 13, cursor: 'pointer',
            }}>✕ Cancel Booking</button>
          )}
          {status !== 'Active' && <div />}

          <div style={{ display: 'flex', gap: 12 }}>
            {status !== 'Completed' && (
              <>
                <button onClick={() => { setShowInvoice(true); }} style={btnOutline}>Issue Invoice</button>
                <button onClick={() => { setPayAmount(String(balance)); setShowPayment(true); }} style={{ ...btnOutline, borderColor: '#0D87A8', color: '#0D87A8' }}>Record Payment</button>
              </>
            )}
            {status === 'Active' && (
              <button onClick={handleCheckIn} disabled={actionLoading} style={btnPrimary}>
                {actionLoading ? 'Processing...' : 'Check-in'}
              </button>
            )}
            {status === 'Checked-in' && (
              <button onClick={handleCheckOut} disabled={actionLoading} style={{ ...btnPrimary, background: '#27AE60' }}>
                {actionLoading ? 'Processing...' : 'Check-out'}
              </button>
            )}
            {status === 'Completed' && (
              <button disabled style={{ ...btnPrimary, background: '#BDC3C7', cursor: 'not-allowed' }}>Completed</button>
            )}
          </div>
        </div>
      )}

      {/* Payment Modal */}
      {showPayment && (
        <Modal title="Record Payment" onClose={() => setShowPayment(false)}>
          <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 13, marginBottom: 16, color: '#9AAAB5' }}>
            <span>Balance Due</span>
            <strong style={{ color: '#C0392B', fontFamily: 'monospace' }}>{formatMoney(balance)} ₫</strong>
          </div>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 4 }}>
            <label style={labelSm}>Amount (₫)</label>
            <div style={{ display: 'flex', gap: 4 }}>
              {[['25%', 0.25], ['50%', 0.5], ['Full', 1]].map(([lbl, pct]) => (
                <button key={lbl} onClick={() => setPayAmount(String(Math.round(balance * pct)))} style={{
                  padding: '2px 8px', border: '1px solid #E2E8ED', borderRadius: 3, background: '#F8FAFB',
                  fontSize: 11, cursor: 'pointer', color: '#5C7080',
                }}>{lbl}</button>
              ))}
            </div>
          </div>
          <input type="number" value={payAmount} onChange={e => setPayAmount(e.target.value)} style={{ ...inputStyle, marginBottom: 12 }} />
          <label style={labelSm}>Method</label>
          <select value={payMethod} onChange={e => setPayMethod(e.target.value)} style={{ ...inputStyle, marginBottom: 20 }}>
            <option>Cash</option><option>Bank Transfer</option><option>Credit Card</option>
          </select>
          <button onClick={handlePayment} disabled={actionLoading} style={{ ...btnPrimary, width: '100%', height: 40 }}>
            {actionLoading ? 'Processing...' : 'Record Payment ✓'}
          </button>
        </Modal>
      )}

      {/* Invoice Modal */}
      {showInvoice && (
        <Modal title="Issue Invoice" onClose={() => setShowInvoice(false)}>
          <div style={{ background: '#F8FAFB', padding: 16, borderRadius: 8, marginBottom: 16 }}>
            <Row left="Total Amount" right={`${formatMoney(totalAmount)} ₫`} bold />
            <Row left="Amount Paid" right={`${formatMoney(amountPaid)} ₫`} color="#27AE60" />
            <div style={{ marginTop: 8, paddingTop: 8, borderTop: '1px solid #E2E8ED' }}>
              <Row left="Balance Due" right={`${formatMoney(balance)} ₫`} color="#C0392B" bold />
            </div>
          </div>
          <p style={{ fontSize: 12, color: '#9AAAB5', marginBottom: 16 }}>
            ℹ️ Invoice can be re-issued to update the latest figures.
          </p>
          <button onClick={handleInvoice} disabled={actionLoading} style={{ ...btnPrimary, width: '100%', height: 40 }}>
            {actionLoading ? 'Processing...' : 'Confirm & Issue Invoice'}
          </button>
        </Modal>
      )}

      {/* Service Modal */}
      {showService && (
        <Modal title="Add Service" onClose={() => { setShowService(false); setSvcQuery(''); }}>
          <input type="text" value={svcQuery} onChange={e => setSvcQuery(e.target.value)}
            placeholder="Search services..." style={{ ...inputStyle, marginBottom: 16 }} autoFocus />
          <div style={{ maxHeight: 250, overflow: 'auto' }}>
            {svcResults.map(svc => (
              <div key={svc.id} onClick={() => handleAddService(svc)} style={{
                display: 'flex', justifyContent: 'space-between', padding: '10px 8px',
                borderBottom: '1px solid #f0f0f0', cursor: 'pointer', fontSize: 13,
              }}
              onMouseEnter={e => e.currentTarget.style.background = '#F8FAFB'}
              onMouseLeave={e => e.currentTarget.style.background = 'transparent'}
              >
                <span>{escapeHtml(svc.name || svc.service_name)}</span>
                <span style={{ fontFamily: 'monospace', color: '#0D87A8' }}>{formatMoney(svc.price)} ₫</span>
              </div>
            ))}
          </div>
        </Modal>
      )}
    </Layout>
  );
}

// ─── Sub-components ──────────────────────────────────────────────────

function Card({ title, action, children }) {
  return (
    <div style={{ background: '#fff', border: '1px solid #E2E8ED', borderRadius: 8, padding: 20 }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', borderBottom: '1px solid #E2E8ED', paddingBottom: 10, marginBottom: 14 }}>
        <h3 style={{ fontSize: 15, fontWeight: 600, margin: 0 }}>{title}</h3>
        {action}
      </div>
      {children}
    </div>
  );
}

function InfoField({ label, value }) {
  return (
    <div>
      <div style={{ fontSize: 12, color: '#9AAAB5', marginBottom: 2 }}>{label}</div>
      <div style={{ fontWeight: 500, fontSize: 14 }}>{escapeHtml(String(value))}</div>
    </div>
  );
}

function Accordion({ label, open, toggle, children }) {
  return (
    <div style={{ borderBottom: '1px solid #f0f0f0', marginBottom: 4 }}>
      <button onClick={toggle} style={{
        width: '100%', display: 'flex', justifyContent: 'space-between', alignItems: 'center',
        padding: '8px 0', background: 'none', border: 'none', cursor: 'pointer',
        fontSize: 13, fontWeight: 600, color: '#2C3E4A',
      }}>
        {label}
        <span style={{ fontSize: 11, transition: 'transform 0.2s', transform: open ? 'rotate(180deg)' : 'none' }}>▼</span>
      </button>
      {open && <div style={{ padding: '0 0 8px 0' }}>{children}</div>}
    </div>
  );
}

function Row({ left, right, bold, color }) {
  return (
    <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 4, fontSize: 13 }}>
      <span style={{ color: bold ? '#2C3E4A' : '#9AAAB5', fontWeight: bold ? 600 : 400 }}>{left}</span>
      <span style={{ fontFamily: 'monospace', fontWeight: bold ? 700 : 400, color: color || '#2C3E4A' }}>{right}</span>
    </div>
  );
}

function Modal({ title, onClose, children }) {
  return (
    <div style={{
      position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.4)', zIndex: 9999,
      display: 'flex', alignItems: 'center', justifyContent: 'center',
    }} onClick={onClose}>
      <div onClick={e => e.stopPropagation()} style={{
        background: '#fff', borderRadius: 12, padding: 24, width: 440,
        boxShadow: '0 20px 60px rgba(0,0,0,0.2)',
      }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 20 }}>
          <h3 style={{ fontSize: 16, fontWeight: 600, margin: 0 }}>{title}</h3>
          <button onClick={onClose} style={{ background: 'none', border: 'none', fontSize: 20, cursor: 'pointer', color: '#9AAAB5' }}>✕</button>
        </div>
        {children}
      </div>
    </div>
  );
}

const labelSm = { fontSize: 12, color: '#9AAAB5', fontWeight: 600, marginBottom: 4 };
const inputStyle = {
  width: '100%', height: 36, border: '1px solid #E2E8ED', borderRadius: 4,
  padding: '0 12px', fontSize: 13, outline: 'none', boxSizing: 'border-box',
};
const btnPrimary = {
  background: '#0D87A8', color: '#fff', border: 'none', borderRadius: 4,
  padding: '8px 20px', fontWeight: 600, fontSize: 13, cursor: 'pointer',
};
const btnOutline = {
  background: 'transparent', border: '1px solid #BDC3C7', borderRadius: 4,
  padding: '8px 16px', fontWeight: 600, fontSize: 13, cursor: 'pointer', color: '#5C7080',
};
const btnSmOutline = {
  background: 'transparent', border: '1px solid #0D87A8', borderRadius: 4,
  padding: '4px 12px', fontWeight: 500, fontSize: 12, cursor: 'pointer', color: '#0D87A8',
};
