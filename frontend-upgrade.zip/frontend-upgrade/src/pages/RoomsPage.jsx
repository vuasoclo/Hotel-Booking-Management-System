// src/pages/RoomsPage.jsx
import { useState, useEffect } from 'react';
import Layout from '../components/Layout';
import LoadingSpinner from '../components/LoadingSpinner';
import { useToast } from '../components/Toast';
import { useAuth } from '../hooks/useAuth';
import { roomsApi, escapeHtml } from '../utils/api';

const STATUS_CONFIG = {
  Available:   { bg: 'rgba(16,185,129,0.08)', border: '#10B981', badge: '#EAFAF1', badgeText: '#059669' },
  Occupied:    { bg: '#EBF5FB',               border: '#2E86C1', badge: 'rgba(46,134,193,0.1)', badgeText: '#1B4F72' },
  Dirty:       { bg: '#FEF9E7',               border: '#F1C40F', badge: 'rgba(241,196,15,0.1)', badgeText: '#B7950B' },
  Maintenance: { bg: '#FDEDEC',               border: '#E74C3C', badge: 'rgba(231,76,60,0.1)',  badgeText: '#922B21' },
};

export default function RoomsPage() {
  const { staffId } = useAuth();
  const toast = useToast();
  const [rooms, setRooms] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState('All');

  const fetchRooms = async () => {
    setLoading(true);
    try {
      const data = await roomsApi.status();
      setRooms(data);
    } catch (err) {
      toast.error('Failed to load rooms: ' + err.message);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { fetchRooms(); }, []);

  const handleClean = async (roomId) => {
    try {
      await roomsApi.housekeeping(roomId, staffId);
      toast.success('Room cleaned successfully!');
      fetchRooms();
    } catch (err) {
      toast.error('Housekeeping failed: ' + err.message);
    }
  };

  // Count by status
  const counts = rooms.reduce((acc, r) => {
    acc[r.physical_status] = (acc[r.physical_status] || 0) + 1;
    return acc;
  }, {});

  // Group filtered rooms by type
  const filteredRooms = filter === 'All' ? rooms : rooms.filter(r => r.physical_status === filter);
  const grouped = {};
  filteredRooms.forEach(r => {
    if (!grouped[r.type_name]) grouped[r.type_name] = [];
    grouped[r.type_name].push(r);
  });

  return (
    <Layout currentPath="/rooms">
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end', marginBottom: 20 }}>
        <h1 style={{ fontSize: 24, fontWeight: 700, color: '#1A2730', margin: 0 }}>Room Status</h1>
        <select value={filter} onChange={e => setFilter(e.target.value)} style={{
          height: 36, border: '1px solid #E2E8ED', borderRadius: 4, padding: '0 12px',
          fontSize: 13, color: '#2C3E4A', width: 150, outline: 'none',
        }}>
          <option value="All">All Status</option>
          {Object.keys(STATUS_CONFIG).map(s => <option key={s}>{s}</option>)}
        </select>
      </div>

      {/* Status summary */}
      <div style={{
        display: 'flex', gap: 12, marginBottom: 24, flexWrap: 'wrap',
        background: '#fff', padding: 16, borderRadius: 8, border: '1px solid #E2E8ED',
      }}>
        {Object.entries(STATUS_CONFIG).map(([status, cfg]) => (
          <button key={status} onClick={() => setFilter(filter === status ? 'All' : status)} style={{
            display: 'flex', alignItems: 'center', gap: 8, padding: '6px 14px',
            borderRadius: 6, border: filter === status ? `2px solid ${cfg.border}` : '1px solid #E2E8ED',
            background: filter === status ? cfg.badge : 'transparent',
            cursor: 'pointer', fontSize: 13, fontWeight: 600,
            color: cfg.badgeText,
          }}>
            <span style={{
              width: 10, height: 10, borderRadius: '50%', background: cfg.border,
            }} />
            {status}: {counts[status] || 0}
          </button>
        ))}
      </div>

      {loading ? <LoadingSpinner text="Loading rooms..." /> : (
        Object.entries(grouped).map(([typeName, typeRooms]) => (
          <div key={typeName} style={{ marginBottom: 32 }}>
            <h2 style={{
              fontSize: 16, fontWeight: 600, color: '#2C3E4A',
              borderBottom: '1px solid #E2E8ED', paddingBottom: 8, marginBottom: 16,
            }}>{escapeHtml(typeName)}</h2>
            <div style={{
              display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(220px, 1fr))', gap: 12,
            }}>
              {typeRooms.map(room => {
                const cfg = STATUS_CONFIG[room.physical_status] || STATUS_CONFIG.Available;
                return (
                  <div key={room.room_id}
                    onClick={() => room.booking_id && (window.location.href = `/booking/${room.booking_id}`)}
                    style={{
                      background: '#fff', border: `2px solid ${cfg.border}`,
                      borderRadius: 8, padding: 16, cursor: room.booking_id ? 'pointer' : 'default',
                      transition: 'transform 0.15s, box-shadow 0.15s',
                    }}
                    onMouseEnter={e => { e.currentTarget.style.transform = 'translateY(-2px)'; e.currentTarget.style.boxShadow = '0 4px 12px rgba(0,0,0,0.08)'; }}
                    onMouseLeave={e => { e.currentTarget.style.transform = 'none'; e.currentTarget.style.boxShadow = 'none'; }}
                  >
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 8 }}>
                      <span style={{ fontSize: 18, fontWeight: 700, color: '#1A2730' }}>
                        {escapeHtml(room.room_number)}
                      </span>
                      <span style={{
                        fontSize: 10, fontWeight: 700, textTransform: 'uppercase',
                        padding: '3px 8px', borderRadius: 4,
                        background: cfg.badge, color: cfg.badgeText,
                      }}>{room.physical_status}</span>
                    </div>

                    {room.physical_status === 'Occupied' && room.current_guest && (
                      <div style={{ fontSize: 13, marginTop: 8 }}>
                        <div style={{ fontWeight: 600, color: '#2C3E4A' }}>{escapeHtml(room.current_guest)}</div>
                        {room.expected_check_out && (
                          <div style={{ color: '#9AAAB5', fontSize: 12, marginTop: 2 }}>
                            → {new Date(room.expected_check_out).toLocaleString('vi-VN', {
                              month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit'
                            })}
                          </div>
                        )}
                      </div>
                    )}

                    {room.physical_status === 'Dirty' && (
                      <div style={{ marginTop: 10, textAlign: 'right' }}>
                        <button onClick={(e) => { e.stopPropagation(); handleClean(room.room_id); }} style={{
                          padding: '4px 14px', border: '1px solid #F1C40F', borderRadius: 4,
                          background: 'transparent', color: '#B7950B', fontWeight: 600,
                          fontSize: 12, cursor: 'pointer',
                        }}>✓ Clean</button>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        ))
      )}
    </Layout>
  );
}
