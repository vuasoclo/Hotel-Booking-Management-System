// src/pages/LoginPage.jsx
import { useState } from 'react';
import { authApi } from '../utils/api';
import { useAuth } from '../hooks/useAuth';

export default function LoginPage() {
  const { login } = useAuth();
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [showPw, setShowPw] = useState(false);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setLoading(true);
    try {
      const data = await authApi.login(username.trim(), password);
      login({
        username: username.trim(),
        name: data.name,
        role: data.role,
        staffId: data.staff_id,
      });
      window.location.href = '/calendar';
    } catch (err) {
      setError(err.detail || 'Sai tài khoản hoặc mật khẩu.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div style={{
      minHeight: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center',
      background: 'linear-gradient(135deg, #063D4F 0%, #0D87A8 100%)',
    }}>
      <div style={{
        width: '100%', maxWidth: 400, background: '#fff', borderRadius: 12,
        padding: 40, boxShadow: '0 20px 60px rgba(0,0,0,0.25)',
      }}>
        <div style={{
          width: 48, height: 48, background: '#0D87A8', borderRadius: 10,
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          margin: '0 auto 16px', color: '#fff'
        }}>
          <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            <path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"/>
          </svg>
        </div>
        <h1 style={{ textAlign: 'center', fontSize: 20, fontWeight: 600, color: '#1A2730', marginBottom: 4 }}>
          Little Hotelier
        </h1>
        <p style={{ textAlign: 'center', fontSize: 12, color: '#9AAAB5', marginBottom: 28 }}>
          Hotel Booking Management System
        </p>

        <form onSubmit={handleSubmit}>
          <div style={{ marginBottom: 16 }}>
            <label style={{ fontSize: 12, fontWeight: 600, marginBottom: 4, display: 'block', color: '#2C3E4A' }}>
              Username
            </label>
            <input
              type="text" value={username} onChange={e => setUsername(e.target.value)}
              placeholder="Enter username" autoComplete="username"
              style={{
                width: '100%', height: 36, border: '1px solid #E2E8ED', borderRadius: 4,
                padding: '0 12px', fontSize: 14, outline: 'none', boxSizing: 'border-box',
              }}
            />
          </div>

          <div style={{ marginBottom: 24 }}>
            <label style={{ fontSize: 12, fontWeight: 600, marginBottom: 4, display: 'block', color: '#2C3E4A' }}>
              Password
            </label>
            <div style={{ position: 'relative' }}>
              <input
                type={showPw ? 'text' : 'password'} value={password}
                onChange={e => setPassword(e.target.value)}
                placeholder="Enter password" autoComplete="current-password"
                style={{
                  width: '100%', height: 36, border: '1px solid #E2E8ED', borderRadius: 4,
                  padding: '0 40px 0 12px', fontSize: 14, outline: 'none', boxSizing: 'border-box',
                }}
              />
              <button type="button" onClick={() => setShowPw(!showPw)} style={{
                position: 'absolute', right: 8, top: 8, background: 'none', border: 'none',
                cursor: 'pointer', color: '#9AAAB5', padding: 0,
              }}>
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  {showPw
                    ? <><path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19M1 1l22 22"/></>
                    : <><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></>
                  }
                </svg>
              </button>
            </div>
          </div>

          {error && (
            <div style={{
              background: '#FDEDEC', color: '#C0392B', padding: '8px 12px',
              borderRadius: 4, fontSize: 13, marginBottom: 16, border: '1px solid #F5C6CB',
            }}>
              {error}
            </div>
          )}

          <button type="submit" disabled={loading} style={{
            width: '100%', height: 40, background: '#0D87A8', color: '#fff',
            border: 'none', borderRadius: 4, fontWeight: 500, fontSize: 14,
            cursor: loading ? 'not-allowed' : 'pointer', opacity: loading ? 0.7 : 1,
            display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8,
          }}>
            {loading ? 'Signing in...' : 'Sign In'}
            {!loading && <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="5" y1="12" x2="19" y2="12"/><polyline points="12 5 19 12 12 19"/></svg>}
          </button>
        </form>
      </div>
    </div>
  );
}
