// src/pages/NewReservationPage.jsx
import { useState, useEffect } from 'react';
import Layout from '../components/Layout';
import LoadingSpinner from '../components/LoadingSpinner';
import { useToast } from '../components/Toast';
import { useAuth } from '../hooks/useAuth';
import { roomsApi, customersApi, bookingsApi, servicesApi, formatMoney, escapeHtml } from '../utils/api';

const BREAKFAST_PRICE = 150000;

function defaultDates() {
  const pad = n => String(n).padStart(2, '0');
  const fmt = (d, h, m) => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}T${pad(h)}:${pad(m)}`;
  const ci = new Date(); ci.setDate(ci.getDate() + 1);
  const co = new Date(); co.setDate(co.getDate() + 2);
  return { checkin: fmt(ci, 14, 0), checkout: fmt(co, 12, 0) };
}

export default function NewReservationPage() {
  const { staffId } = useAuth();
  const toast = useToast();
  const [step, setStep] = useState(1); // 1: search, 2: guest+services, 3: confirm

  // Step 1: dates + room search
  const defaults = defaultDates();
  const [checkin, setCheckin] = useState(defaults.checkin);
  const [checkout, setCheckout] = useState(defaults.checkout);
  const [availableRooms, setAvailableRooms] = useState([]);
  const [selectedRooms, setSelectedRooms] = useState([]);
  const [searchLoading, setSearchLoading] = useState(false);
  const [searched, setSearched] = useState(false);

  // Step 2: guest + services
  const [phone, setPhone] = useState('');
  const [guestName, setGuestName] = useState('');
  const [guestId, setGuestId] = useState('');
  const [customerId, setCustomerId] = useState(null);
  const [lookupLoading, setLookupLoading] = useState(false);

  // Services
  const [services, setServices] = useState([]);
  const [serviceQuery, setServiceQuery] = useState('');
  const [serviceResults, setServiceResults] = useState([]);
  const [showServiceModal, setShowServiceModal] = useState(false);

  // Booking
  const [submitting, setSubmitting] = useState(false);

  const earlyCheckin = checkin && new Date(checkin).getHours() < 14;

  // Calculated costs
  const nights = checkin && checkout ? Math.max(Math.ceil((new Date(checkout) - new Date(checkin)) / 86400000), 1) : 0;
  const roomCost = selectedRooms.reduce((sum, r) => sum + r.price * r.qty * nights, 0);
  const serviceCost = services.reduce((sum, s) => sum + s.price * s.qty, 0);
  const total = roomCost + serviceCost;

  // Search rooms
  const handleSearch = async () => {
    if (!checkin || !checkout) { toast.warning('Please select dates'); return; }
    if (checkout <= checkin) { toast.warning('Check-out must be after check-in'); return; }
    setSearchLoading(true);
    try {
      const ciDate = checkin.split('T')[0];
      const coDate = checkout.split('T')[0];
      const data = await roomsApi.available(ciDate, coDate);
      setAvailableRooms(data.filter(r => r.min_available > 0));
      setSearched(true);
    } catch (err) {
      toast.error('Search failed: ' + err.message);
    } finally {
      setSearchLoading(false);
    }
  };

  const addRoom = (room, withBreakfast) => {
    const key = `${room.room_type_id}-${withBreakfast}`;
    const existing = selectedRooms.find(r => r.key === key);
    const totalOfType = selectedRooms.filter(r => r.typeId === room.room_type_id).reduce((s, r) => s + r.qty, 0);
    if (totalOfType >= room.min_available) {
      toast.warning(`Only ${room.min_available} rooms of type ${room.type_name} available`);
      return;
    }
    if (existing) {
      setSelectedRooms(prev => prev.map(r => r.key === key ? { ...r, qty: r.qty + 1 } : r));
    } else {
      setSelectedRooms(prev => [...prev, {
        key, typeId: room.room_type_id, typeName: room.type_name,
        price: room.base_price + (withBreakfast ? BREAKFAST_PRICE : 0),
        qty: 1, breakfast: withBreakfast, maxAvail: room.min_available,
      }]);
    }
  };

  const removeRoom = (key) => setSelectedRooms(prev => prev.filter(r => r.key !== key));

  // Guest lookup
  const handleLookup = async () => {
    if (!phone.trim()) return;
    setLookupLoading(true);
    try {
      const data = await customersApi.lookup(phone.trim());
      if (data) {
        setGuestName(data.full_name || '');
        setGuestId(data.identity_card || '');
        setCustomerId(data.customer_id);
        toast.success('Guest found!');
      } else {
        toast.warning('Guest not found in system');
        setCustomerId(null);
      }
    } catch {
      toast.warning('Guest not found in system');
      setCustomerId(null);
    } finally {
      setLookupLoading(false);
    }
  };

  // Service search
  useEffect(() => {
    if (!serviceQuery.trim()) { setServiceResults([]); return; }
    const timeout = setTimeout(async () => {
      try {
        const data = await servicesApi.search(serviceQuery);
        setServiceResults(data);
      } catch {}
    }, 300);
    return () => clearTimeout(timeout);
  }, [serviceQuery]);

  const addService = (svc) => {
    const existing = services.find(s => s.id === svc.id);
    if (existing) {
      setServices(prev => prev.map(s => s.id === svc.id ? { ...s, qty: s.qty + 1 } : s));
    } else {
      setServices(prev => [...prev, { id: svc.id, name: svc.name || svc.service_name, price: svc.price, qty: 1 }]);
    }
    setShowServiceModal(false);
    setServiceQuery('');
    toast.success(`Added ${svc.name || svc.service_name}`);
  };

  // Submit booking
  const handleSubmit = async () => {
    if (!customerId) { toast.error('Please lookup guest first'); return; }
    setSubmitting(true);
    try {
      const payload = {
        hotel_id: 1,
        customer_id: customerId,
        check_in: checkin.replace('T', ' ') + ':00',
        check_out: checkout.replace('T', ' ') + ':00',
        idempotency_key: crypto.randomUUID(),
        staff_id: staffId,
        rooms: selectedRooms.map(r => ({
          room_type_id: r.typeId, quantity: r.qty, is_breakfast_included: r.breakfast,
        })),
        services: services.map(s => ({ service_id: s.id, quantity: s.qty })),
      };
      await bookingsApi.create(payload);
      toast.success('Booking created successfully!');
      window.location.href = '/calendar';
    } catch (err) {
      toast.error(err.detail || 'Booking failed');
    } finally {
      setSubmitting(false);
    }
  };

  const canProceed = selectedRooms.length > 0;
  const canBook = customerId && canProceed;

  return (
    <Layout currentPath="/new-reservation">
      <div style={{ fontSize: 12, color: '#9AAAB5', marginBottom: 4 }}>Home {'>'} Reservations {'>'} New</div>
      <h1 style={{ fontSize: 24, fontWeight: 700, color: '#1A2730', marginBottom: 24 }}>New Reservation</h1>

      {/* Stepper indicator */}
      <div style={{ display: 'flex', gap: 16, marginBottom: 24 }}>
        {['Room Selection', 'Guest & Services', 'Confirm'].map((label, i) => (
          <div key={i} style={{
            display: 'flex', alignItems: 'center', gap: 8,
            color: step >= i + 1 ? '#0D87A8' : '#9AAAB5', fontWeight: step === i + 1 ? 600 : 400, fontSize: 13,
          }}>
            <span style={{
              width: 24, height: 24, borderRadius: '50%', display: 'flex', alignItems: 'center', justifyContent: 'center',
              background: step > i + 1 ? '#0D87A8' : step === i + 1 ? '#EFF8FB' : '#F1F4F6',
              color: step > i + 1 ? '#fff' : step === i + 1 ? '#0D87A8' : '#9AAAB5',
              fontSize: 12, fontWeight: 600, border: step === i + 1 ? '1.5px solid #0D87A8' : 'none',
            }}>{step > i + 1 ? '✓' : i + 1}</span>
            {label}
            {i < 2 && <span style={{ color: '#E2E8ED', margin: '0 4px' }}>—</span>}
          </div>
        ))}
      </div>

      <div style={{ display: 'flex', gap: 24 }}>
        {/* Left panel */}
        <div style={{ flex: step >= 2 ? '0 0 55%' : '1', transition: 'all 0.3s' }}>
          <div style={{ background: '#fff', border: '1px solid #E2E8ED', borderRadius: 8, padding: 24 }}>
            <h2 style={{ fontSize: 16, fontWeight: 600, marginBottom: 20 }}>Room Search & Selection</h2>

            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16, marginBottom: 16 }}>
              <div>
                <label style={{ fontSize: 12, fontWeight: 600, marginBottom: 4, display: 'block' }}>Check-in</label>
                <input type="datetime-local" value={checkin} onChange={e => setCheckin(e.target.value)}
                  style={inputStyle} />
              </div>
              <div>
                <label style={{ fontSize: 12, fontWeight: 600, marginBottom: 4, display: 'block' }}>Check-out</label>
                <input type="datetime-local" value={checkout} onChange={e => setCheckout(e.target.value)}
                  style={inputStyle} />
              </div>
            </div>

            {earlyCheckin && (
              <div style={{ background: '#FEF3C7', border: '1px solid #FBBF24', borderRadius: 6, padding: '8px 12px', fontSize: 12, color: '#92400E', marginBottom: 16 }}>
                ⚡ Check-in before 14:00 will incur an Early Check-in surcharge.
              </div>
            )}

            <div style={{ display: 'flex', justifyContent: 'flex-end', marginBottom: 20, paddingBottom: 20, borderBottom: '1px solid #E2E8ED' }}>
              <button onClick={handleSearch} disabled={searchLoading} style={{
                ...btnPrimary, opacity: searchLoading ? 0.7 : 1,
              }}>{searchLoading ? 'Searching...' : '🔍 Search Availability'}</button>
            </div>

            {searched && (
              <>
                <h3 style={{ fontSize: 13, fontWeight: 600, color: '#5C7080', textTransform: 'uppercase', marginBottom: 12 }}>Available Rooms</h3>
                {availableRooms.length === 0 ? (
                  <p style={{ color: '#9AAAB5', fontSize: 13 }}>No rooms available for selected dates.</p>
                ) : (
                  <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 13, marginBottom: 24 }}>
                    <thead>
                      <tr style={{ borderBottom: '1px solid #E2E8ED' }}>
                        {['Room Type', 'Available', 'Price/Night', 'Action'].map(h => (
                          <th key={h} style={{ padding: '8px 12px', textAlign: 'left', fontSize: 11, fontWeight: 600, color: '#5C7080', textTransform: 'uppercase' }}>{h}</th>
                        ))}
                      </tr>
                    </thead>
                    <tbody>
                      {availableRooms.map(room => (
                        <tr key={room.room_type_id} style={{ borderBottom: '1px solid #f0f0f0' }}>
                          <td style={{ padding: '10px 12px', fontWeight: 500 }}>{escapeHtml(room.type_name)}</td>
                          <td style={{ padding: '10px 12px' }}>{room.min_available}</td>
                          <td style={{ padding: '10px 12px', fontFamily: 'monospace' }}>{formatMoney(room.base_price)} ₫</td>
                          <td style={{ padding: '10px 12px' }}>
                            <div style={{ display: 'flex', gap: 6 }}>
                              <button onClick={() => addRoom(room, false)} style={btnOutline}>+ Room</button>
                              <button onClick={() => addRoom(room, true)} style={{ ...btnOutline, color: '#B7950B', borderColor: '#F1C40F' }}>+ Breakfast</button>
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                )}

                {/* Selected rooms */}
                <h3 style={{ fontSize: 13, fontWeight: 600, color: '#5C7080', textTransform: 'uppercase', marginBottom: 12 }}>
                  Selected Rooms <span style={{ background: '#5C7080', color: '#fff', padding: '1px 8px', borderRadius: 10, fontSize: 11 }}>
                    {selectedRooms.reduce((s, r) => s + r.qty, 0)}
                  </span>
                </h3>
                {selectedRooms.length === 0 ? (
                  <p style={{ color: '#9AAAB5', fontSize: 13 }}>No rooms selected yet.</p>
                ) : (
                  <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 13, border: '1px solid #E2E8ED', borderRadius: 8 }}>
                    <thead>
                      <tr style={{ borderBottom: '1px solid #E2E8ED', background: '#F8FAFB' }}>
                        {['Room Type', 'Qty', 'Subtotal', ''].map(h => (
                          <th key={h} style={{ padding: '8px 12px', textAlign: 'left', fontSize: 11, fontWeight: 600, color: '#5C7080' }}>{h}</th>
                        ))}
                      </tr>
                    </thead>
                    <tbody>
                      {selectedRooms.map(r => (
                        <tr key={r.key} style={{ borderBottom: '1px solid #f0f0f0' }}>
                          <td style={{ padding: '10px 12px' }}>
                            {escapeHtml(r.typeName)}
                            {r.breakfast && <span style={{ fontSize: 10, background: '#FEF3C7', color: '#92400E', padding: '1px 6px', borderRadius: 4, marginLeft: 6 }}>🍳 B</span>}
                          </td>
                          <td style={{ padding: '10px 12px' }}>{r.qty}</td>
                          <td style={{ padding: '10px 12px', fontFamily: 'monospace' }}>{formatMoney(r.price * r.qty * nights)} ₫</td>
                          <td style={{ padding: '10px 12px' }}>
                            <button onClick={() => removeRoom(r.key)} style={{ background: 'none', border: 'none', color: '#E74C3C', cursor: 'pointer', fontSize: 16 }}>✕</button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                )}

                {step === 1 && canProceed && (
                  <div style={{ display: 'flex', justifyContent: 'flex-end', marginTop: 20, paddingTop: 16, borderTop: '1px solid #E2E8ED' }}>
                    <button onClick={() => setStep(2)} style={btnPrimary}>
                      Proceed to Booking →
                    </button>
                  </div>
                )}
              </>
            )}
          </div>
        </div>

        {/* Right panel - Guest & Services */}
        {step >= 2 && (
          <div style={{ flex: '0 0 42%' }}>
            <div style={{ background: '#fff', border: '1px solid #E2E8ED', borderRadius: 8, padding: 24, position: 'sticky', top: 24 }}>
              <h2 style={{ fontSize: 16, fontWeight: 600, marginBottom: 20 }}>Guest & Booking Details</h2>

              {/* Guest section */}
              <h3 style={sectionTitle}>1. Guest Information</h3>
              <div style={{ display: 'flex', gap: 8, marginBottom: 12 }}>
                <input type="text" value={phone} onChange={e => setPhone(e.target.value)}
                  placeholder="Phone number" style={{ ...inputStyle, flex: 1 }} />
                <button onClick={handleLookup} disabled={lookupLoading} style={{
                  ...btnOutline, padding: '0 12px', height: 36,
                }}>{lookupLoading ? '...' : '🔍'}</button>
              </div>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12, marginBottom: 20 }}>
                <div>
                  <label style={labelStyle}>Full Name</label>
                  <input type="text" value={guestName} readOnly style={{ ...inputStyle, background: '#F8FAFB' }} />
                </div>
                <div>
                  <label style={labelStyle}>ID Number</label>
                  <input type="text" value={guestId} readOnly style={{ ...inputStyle, background: '#F8FAFB' }} />
                </div>
              </div>

              {/* Services section */}
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 }}>
                <h3 style={{ ...sectionTitle, margin: 0 }}>2. Additional Services</h3>
                <button onClick={() => setShowServiceModal(true)} style={{ ...btnOutline, fontSize: 12 }}>+ Add Service</button>
              </div>
              {services.length > 0 && (
                <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 12, marginBottom: 16 }}>
                  <tbody>
                    {services.map((s, i) => (
                      <tr key={s.id} style={{ borderBottom: '1px solid #f0f0f0' }}>
                        <td style={{ padding: '6px 0' }}>{escapeHtml(s.name)}</td>
                        <td style={{ padding: '6px 8px', fontFamily: 'monospace' }}>{formatMoney(s.price)}</td>
                        <td style={{ padding: '6px 8px' }}>×{s.qty}</td>
                        <td style={{ padding: '6px 8px', fontFamily: 'monospace' }}>{formatMoney(s.price * s.qty)}</td>
                        <td><button onClick={() => setServices(prev => prev.filter((_, idx) => idx !== i))} style={{ background: 'none', border: 'none', color: '#E74C3C', cursor: 'pointer' }}>✕</button></td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              )}

              {/* Cost summary */}
              <div style={{ background: '#F8FAFB', padding: 16, borderRadius: 8, border: '1px solid #E2E8ED', marginBottom: 20 }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 4, fontSize: 13, color: '#5C7080' }}>
                  <span>Room cost ({nights} night{nights > 1 ? 's' : ''})</span>
                  <span style={{ fontFamily: 'monospace' }}>{formatMoney(roomCost)} ₫</span>
                </div>
                <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 8, fontSize: 13, color: '#5C7080' }}>
                  <span>Services</span>
                  <span style={{ fontFamily: 'monospace' }}>{formatMoney(serviceCost)} ₫</span>
                </div>
                <div style={{ display: 'flex', justifyContent: 'space-between', paddingTop: 8, borderTop: '1px solid #E2E8ED' }}>
                  <strong style={{ color: '#0D87A8' }}>TOTAL</strong>
                  <strong style={{ color: '#0D87A8', fontSize: 20, fontFamily: 'monospace' }}>{formatMoney(total)} ₫</strong>
                </div>
              </div>

              <div style={{ display: 'flex', gap: 12 }}>
                <button onClick={() => setStep(1)} style={{ ...btnOutline, flex: 1, height: 40 }}>← Back</button>
                <button onClick={handleSubmit} disabled={!canBook || submitting} style={{
                  ...btnPrimary, flex: 1, height: 40, opacity: !canBook || submitting ? 0.5 : 1,
                }}>{submitting ? 'Processing...' : 'Book Now →'}</button>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Service modal */}
      {showServiceModal && (
        <div style={{
          position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.4)', zIndex: 9999,
          display: 'flex', alignItems: 'center', justifyContent: 'center',
        }} onClick={() => setShowServiceModal(false)}>
          <div onClick={e => e.stopPropagation()} style={{
            background: '#fff', borderRadius: 12, padding: 24, width: 480,
            maxHeight: '80vh', overflow: 'auto', boxShadow: '0 20px 60px rgba(0,0,0,0.2)',
          }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 }}>
              <h3 style={{ fontSize: 16, fontWeight: 600, margin: 0 }}>Add Service</h3>
              <button onClick={() => setShowServiceModal(false)} style={{ background: 'none', border: 'none', fontSize: 20, cursor: 'pointer', color: '#9AAAB5' }}>✕</button>
            </div>
            <input type="text" value={serviceQuery} onChange={e => setServiceQuery(e.target.value)}
              placeholder="Search services (e.g. Spa, Airport)..."
              style={{ ...inputStyle, width: '100%', marginBottom: 16 }} autoFocus />
            {serviceResults.length > 0 && (
              <div style={{ maxHeight: 250, overflow: 'auto' }}>
                {serviceResults.map(svc => (
                  <div key={svc.id} onClick={() => addService(svc)} style={{
                    display: 'flex', justifyContent: 'space-between', alignItems: 'center',
                    padding: '10px 12px', borderBottom: '1px solid #f0f0f0', cursor: 'pointer',
                    fontSize: 13, transition: 'background 0.1s',
                  }}
                  onMouseEnter={e => e.currentTarget.style.background = '#F8FAFB'}
                  onMouseLeave={e => e.currentTarget.style.background = 'transparent'}
                  >
                    <div>
                      <div style={{ fontWeight: 500 }}>{escapeHtml(svc.name || svc.service_name)}</div>
                      <div style={{ fontSize: 11, color: '#9AAAB5' }}>{escapeHtml(svc.category || '')}</div>
                    </div>
                    <span style={{ fontFamily: 'monospace', color: '#0D87A8' }}>{formatMoney(svc.price)} ₫</span>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}
    </Layout>
  );
}

const inputStyle = {
  height: 36, border: '1px solid #E2E8ED', borderRadius: 4, padding: '0 12px',
  fontSize: 13, outline: 'none', boxSizing: 'border-box', width: '100%',
};
const labelStyle = { fontSize: 12, fontWeight: 600, marginBottom: 4, display: 'block', color: '#2C3E4A' };
const sectionTitle = { fontSize: 13, fontWeight: 600, color: '#5C7080', textTransform: 'uppercase', borderBottom: '1px solid #E2E8ED', paddingBottom: 8, marginBottom: 12 };
const btnPrimary = {
  background: '#0D87A8', color: '#fff', border: 'none', borderRadius: 4,
  padding: '8px 20px', fontWeight: 500, fontSize: 13, cursor: 'pointer',
};
const btnOutline = {
  background: 'transparent', border: '1px solid #0D87A8', borderRadius: 4,
  padding: '4px 12px', fontWeight: 500, fontSize: 13, cursor: 'pointer', color: '#0D87A8',
};
