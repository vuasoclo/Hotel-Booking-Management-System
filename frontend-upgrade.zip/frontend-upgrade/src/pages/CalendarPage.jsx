// src/pages/CalendarPage.jsx
import { useState, useEffect, useCallback } from 'react';
import Layout from '../components/Layout';
import LoadingSpinner from '../components/LoadingSpinner';
import { useToast } from '../components/Toast';
import { useAuth } from '../hooks/useAuth';
import { calendarApi, formatDateShort } from '../utils/api';

const TOTAL_DAYS = 14; // upgraded from 7 to 14

function getDateStr(date) {
  return date.toISOString().split('T')[0];
}

function addDays(date, n) {
  const d = new Date(date);
  d.setDate(d.getDate() + n);
  return d;
}

export default function CalendarPage() {
  const { staffId } = useAuth();
  const toast = useToast();
  const [startDate, setStartDate] = useState(() => {
    const d = new Date(); d.setHours(0, 0, 0, 0); return d;
  });
  const [loading, setLoading] = useState(true);
  const [roomTypes, setRoomTypes] = useState([]);
  const [rooms, setRooms] = useState([]);
  const [bookings, setBookings] = useState([]);
  const [tooltip, setTooltip] = useState(null);

  const endDate = addDays(startDate, TOTAL_DAYS - 1);

  const fetchCalendar = useCallback(async () => {
    setLoading(true);
    try {
      const data = await calendarApi.get(getDateStr(startDate), getDateStr(endDate));
      processData(data);
    } catch (err) {
      toast.error('Failed to load calendar: ' + err.message);
    } finally {
      setLoading(false);
    }
  }, [startDate]);

  useEffect(() => { fetchCalendar(); }, [fetchCalendar]);

  function processData(data) {
    const typeMap = new Map();
    const roomMap = new Map();
    const bkList = [];

    data.forEach(item => {
      if (!typeMap.has(item.room_type_id)) {
        typeMap.set(item.room_type_id, { id: item.room_type_id, name: item.type_name });
      }
      if (!roomMap.has(item.room_id)) {
        roomMap.set(item.room_id, {
          id: item.room_id, name: item.room_number,
          typeId: item.room_type_id, status: item.room_status
        });
      }
      if (item.booking_id && item.check_in && item.check_out) {
        const ciDate = new Date(item.check_in);
        const coDate = new Date(item.check_out);
        const startOffset = Math.round((ciDate - startDate) / 86400000);
        let length = Math.round((coDate - ciDate) / 86400000);
        const adjStart = Math.max(startOffset, 0);
        const adjLen = Math.min(length - (adjStart - startOffset), TOTAL_DAYS - adjStart);

        if (adjLen > 0 && adjStart < TOTAL_DAYS) {
          const inits = item.customer_name
            ? item.customer_name.split(' ').map(n => n[0]).join('').substring(0, 2).toUpperCase()
            : 'G';
          bkList.push({
            id: item.booking_id, guest: item.customer_name || 'Guest',
            phone: item.customer_phone || '', inits,
            roomId: item.room_id, status: item.booking_status,
            start: adjStart, length: adjLen,
            checkIn: item.check_in, checkOut: item.check_out,
          });
        }
      }
    });

    setRoomTypes([...typeMap.values()]);
    setRooms([...roomMap.values()]);
    setBookings(bkList);
  }

  const shiftDate = (days) => {
    if (days === 0) {
      const d = new Date(); d.setHours(0, 0, 0, 0);
      setStartDate(d);
    } else {
      setStartDate(prev => addDays(prev, days));
    }
  };

  const handleDefragment = async () => {
    try {
      await calendarApi.defragment(1, staffId);
      toast.success('Room allocation optimized!');
      fetchCalendar();
    } catch (err) {
      toast.error('Defragment failed: ' + err.message);
    }
  };

  // Date headers
  const dateHeaders = [];
  for (let i = 0; i < TOTAL_DAYS; i++) {
    const d = addDays(startDate, i);
    const isToday = getDateStr(d) === getDateStr(new Date());
    const isWeekend = d.getDay() === 0 || d.getDay() === 6;
    dateHeaders.push({ date: d, dayName: d.toLocaleDateString('en-GB', { weekday: 'short' }),
      dayNum: d.getDate().toString().padStart(2, '0'), isToday, isWeekend });
  }

  return (
    <Layout currentPath="/calendar">
      {/* Toolbar */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 20 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
          <div style={{ display: 'flex' }}>
            <button onClick={() => shiftDate(-7)} style={navBtnStyle}>◀◀</button>
            <button onClick={() => shiftDate(-1)} style={navBtnStyle}>◀</button>
            <button onClick={() => shiftDate(1)} style={navBtnStyle}>▶</button>
            <button onClick={() => shiftDate(7)} style={navBtnStyle}>▶▶</button>
          </div>
          <span style={{ fontWeight: 600, padding: '0 8px', fontSize: 14 }}>
            {formatDateShort(startDate)} — {formatDateShort(endDate)}
          </span>
          <button onClick={() => shiftDate(0)} style={{
            ...navBtnStyle, padding: '4px 12px', fontWeight: 500
          }}>Today</button>
        </div>
        <div style={{ display: 'flex', gap: 8 }}>
          <button onClick={handleDefragment} style={{
            padding: '6px 14px', borderRadius: 4, border: '1px solid #0D87A8',
            background: 'transparent', color: '#0D87A8', fontWeight: 600, fontSize: 13, cursor: 'pointer'
          }}>⊞ Defragment</button>
          <a href="/new-reservation" style={{
            padding: '6px 14px', borderRadius: 4, border: 'none',
            background: '#0D87A8', color: '#fff', fontWeight: 500, fontSize: 13,
            textDecoration: 'none', display: 'flex', alignItems: 'center', gap: 4,
          }}>+ New Reservation</a>
        </div>
      </div>

      {loading ? <LoadingSpinner text="Loading calendar..." /> : (
        <div style={{
          background: '#fff', border: '1px solid #E2E8ED', borderRadius: 8,
          overflow: 'auto', position: 'relative',
        }}>
          {/* Date header row */}
          <div style={{ display: 'flex', position: 'sticky', top: 0, zIndex: 20, background: '#fff' }}>
            <div style={{
              width: 140, minWidth: 140, position: 'sticky', left: 0,
              background: '#F8FAFB', borderRight: '2px solid #E2E8ED', borderBottom: '1px solid #E2E8ED',
              display: 'flex', alignItems: 'center', padding: '0 12px',
              fontWeight: 600, fontSize: 12, color: '#5C7080', textTransform: 'uppercase', zIndex: 25,
            }}>Rooms</div>
            {dateHeaders.map((h, i) => (
              <div key={i} style={{
                flex: '1 0 80px', minWidth: 80, height: 48,
                borderRight: '1px solid #E2E8ED', borderBottom: '1px solid #E2E8ED',
                display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center',
                background: h.isToday ? '#EFF8FB' : h.isWeekend ? '#FEF9E7' : '#F8FAFB',
              }}>
                <span style={{ fontSize: 11, color: '#9AAAB5' }}>{h.dayName}</span>
                <strong style={{ fontSize: 14, color: h.isToday ? '#0D87A8' : '#2C3E4A' }}>{h.dayNum}</strong>
              </div>
            ))}
          </div>

          {/* Grid rows */}
          {roomTypes.map(type => (
            <div key={type.id}>
              {/* Type header */}
              <div style={{
                display: 'flex', height: 36, alignItems: 'center', padding: '0 12px',
                background: '#F1F4F6', fontWeight: 600, fontSize: 12, color: '#5C7080',
                textTransform: 'uppercase', borderBottom: '1px solid #E2E8ED',
              }}>{type.name}</div>

              {/* Room rows */}
              {rooms.filter(r => r.typeId === type.id).map(room => {
                const roomBookings = bookings.filter(b => b.roomId === room.id);
                const isDirty = room.status === 'Dirty';
                const isMaint = room.status === 'Maintenance';

                return (
                  <div key={room.id} style={{
                    display: 'flex', height: 48, position: 'relative',
                    borderBottom: '1px solid #E2E8ED',
                    background: isDirty ? 'repeating-linear-gradient(45deg, transparent, transparent 10px, rgba(245,158,11,0.06) 10px, rgba(245,158,11,0.06) 20px)'
                      : isMaint ? 'rgba(239,68,68,0.05)' : 'transparent',
                  }}>
                    {/* Room label */}
                    <div style={{
                      width: 140, minWidth: 140, position: 'sticky', left: 0,
                      background: '#fff', borderRight: '2px solid #E2E8ED',
                      display: 'flex', alignItems: 'center', padding: '0 12px', zIndex: 10,
                      fontWeight: 500, fontSize: 13, gap: 8,
                    }}>
                      {room.name}
                      {isDirty && <span style={{ fontSize: 9, background: '#FEF3C7', color: '#B7950B', padding: '1px 4px', borderRadius: 3 }}>DIRTY</span>}
                      {isMaint && <span style={{ fontSize: 9, background: '#FDEDEC', color: '#C0392B', padding: '1px 4px', borderRadius: 3 }}>MAINT</span>}
                    </div>

                    {/* Day cells */}
                    <div style={{ display: 'flex', flex: 1, position: 'relative' }}>
                      {dateHeaders.map((h, i) => (
                        <div key={i} style={{
                          flex: '1 0 80px', minWidth: 80,
                          borderRight: '1px solid #f0f0f0',
                          background: h.isToday ? 'rgba(13,135,168,0.03)' : 'transparent',
                        }} />
                      ))}

                      {/* Booking blocks */}
                      {roomBookings.map((bk, idx) => {
                        const leftPct = (bk.start / TOTAL_DAYS) * 100;
                        const widthPct = (bk.length / TOTAL_DAYS) * 100;
                        const isActive = bk.status === 'Active';

                        return (
                          <a key={idx} href={`/booking/${bk.id}`}
                            onMouseEnter={(e) => {
                              const rect = e.target.getBoundingClientRect();
                              setTooltip({
                                x: rect.left + rect.width / 2,
                                y: rect.top - 8,
                                guest: bk.guest, phone: bk.phone,
                                checkIn: bk.checkIn, checkOut: bk.checkOut,
                                status: bk.status, id: bk.id,
                              });
                            }}
                            onMouseLeave={() => setTooltip(null)}
                            style={{
                              position: 'absolute', left: `${leftPct}%`,
                              width: `calc(${widthPct}% - 4px)`, height: 40, top: 4,
                              borderRadius: 6, padding: '4px 8px', fontSize: 12,
                              display: 'flex', alignItems: 'center', gap: 6,
                              textDecoration: 'none', cursor: 'pointer', zIndex: 5,
                              overflow: 'hidden', whiteSpace: 'nowrap', textOverflow: 'ellipsis',
                              transition: 'filter 0.15s',
                              background: isActive ? 'rgba(59,130,246,0.12)' : 'rgba(13,135,168,0.12)',
                              border: isActive ? '2px dashed #3B82F6' : '2px solid #0D87A8',
                              color: isActive ? '#1d4ed8' : '#0A6B87',
                            }}
                          >
                            <span style={{
                              width: 22, height: 22, borderRadius: '50%', flexShrink: 0,
                              background: isActive ? '#3B82F6' : '#0D87A8', color: '#fff',
                              fontSize: 9, fontWeight: 600, display: 'flex', alignItems: 'center', justifyContent: 'center',
                            }}>{bk.inits}</span>
                            <strong style={{ fontSize: 11 }}>{bk.guest}</strong>
                          </a>
                        );
                      })}
                    </div>
                  </div>
                );
              })}
            </div>
          ))}
        </div>
      )}

      {/* Tooltip */}
      {tooltip && (
        <div style={{
          position: 'fixed', left: tooltip.x, top: tooltip.y, transform: 'translate(-50%, -100%)',
          background: '#1A2730', color: '#fff', padding: '10px 14px', borderRadius: 8,
          fontSize: 12, zIndex: 9999, boxShadow: '0 4px 20px rgba(0,0,0,0.25)',
          pointerEvents: 'none', minWidth: 180,
        }}>
          <div style={{ fontWeight: 600, marginBottom: 4 }}>Booking #{tooltip.id} — {tooltip.guest}</div>
          {tooltip.phone && <div style={{ color: '#9AAAB5' }}>📞 {tooltip.phone}</div>}
          <div style={{ color: '#9AAAB5', marginTop: 4 }}>
            {new Date(tooltip.checkIn).toLocaleDateString('vi-VN')} → {new Date(tooltip.checkOut).toLocaleDateString('vi-VN')}
          </div>
          <div style={{
            display: 'inline-block', marginTop: 6, padding: '2px 8px', borderRadius: 4,
            background: tooltip.status === 'Active' ? 'rgba(59,130,246,0.2)' : 'rgba(13,135,168,0.2)',
            color: tooltip.status === 'Active' ? '#93C5FD' : '#67E8F9',
            fontSize: 11, fontWeight: 600,
          }}>{tooltip.status}</div>
        </div>
      )}
    </Layout>
  );
}

const navBtnStyle = {
  padding: '4px 10px', border: '1px solid #E2E8ED', background: '#fff',
  cursor: 'pointer', fontSize: 12, color: '#5C7080',
};
